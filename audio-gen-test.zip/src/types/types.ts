export type ffmpegQuery = {

}